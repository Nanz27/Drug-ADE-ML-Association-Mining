import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  BarChart3,
  Brain,
  CheckCircle2,
  ChevronDown,
  Cpu,
  FileText,
  Gauge,
  Hash,
  Layers,
  Network,
  RotateCcw,
  Sparkles,
  Timer,
} from "lucide-react";
import {
  EXAMPLE_INPUT,
  analyzeReview,
  loadAssociationRules,
  rulesForDrug,
  type AnalysisResult,
  type AssociationRule,
} from "@/lib/analysis";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Drug–ADE Insight Engine · Hybrid NLP Pharmacovigilance Prototype" },
      {
        name: "description",
        content:
          "Research prototype that analyzes patient medication reviews to detect possible adverse drug events, predict ADE-related reviews, and explore Drug–ADE association patterns.",
      },
      { property: "og:title", content: "Drug–ADE Insight Engine" },
      {
        property: "og:description",
        content:
          "Hybrid NLP-powered analysis of patient reviews: ADE extraction, context, SVM ADE prediction and association rule mining.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const pct = (n: number) => `${Math.round(n * 100)}%`;

/* ---------------- small building blocks ---------------- */

function Card({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`rounded-2xl border border-border bg-card shadow-card transition duration-300 hover:-translate-y-0.5 hover:shadow-lift ${className}`}
    >
      {children}
    </div>
  );
}

function SectionTitle({
  icon,
  title,
  badge,
  description,
}: {
  icon?: React.ReactNode;
  title: string;
  badge?: React.ReactNode;
  description?: string;
}) {
  return (
    <div className="mb-5">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 sm:flex sm:flex-wrap sm:justify-between">
        <div className="flex min-w-0 items-center gap-2.5">
          {icon ? <span className="shrink-0 text-accent">{icon}</span> : null}
          <h2 className="truncate text-lg font-semibold tracking-tight sm:text-xl">
            {title}
          </h2>
        </div>
        {badge}
      </div>
      {description ? (
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">
          {description}
        </p>
      ) : null}
    </div>
  );
}

function Pill({
  children,
  tone = "neutral",
}: {
  children: React.ReactNode;
  tone?: "neutral" | "teal" | "warn" | "info";
}) {
  const tones: Record<string, string> = {
    neutral: "bg-muted text-secondary-foreground border-border",
    teal: "bg-teal-soft text-teal border-teal/25",
    warn: "bg-warn-soft text-warn border-warn/30",
    info: "bg-info-soft text-accent border-accent/25",
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

function Meter({
  value,
  label,
  size = "sm",
}: {
  value: number;
  label: string;
  size?: "sm" | "lg";
}) {
  const [w, setW] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setW(value), 80);
    return () => clearTimeout(t);
  }, [value]);
  return (
    <div
      role="meter"
      aria-valuenow={Math.round(value * 100)}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label}
      className={`w-full overflow-hidden rounded-full bg-muted ${size === "lg" ? "h-3" : "h-2"}`}
    >
      <div
        className="meter-fill h-full rounded-full bg-accent"
        style={{ width: `${Math.round(w * 100)}%` }}
      />
    </div>
  );
}

function Stat({
  icon,
  label,
  children,
}: {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-xl border border-border bg-background p-4">
      <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
        <span className="shrink-0 text-accent">{icon}</span>
        {label}
      </div>
      <div className="mt-2 text-base font-semibold text-foreground">{children}</div>
    </div>
  );
}

/* ---------------- page ---------------- */

const NLP_STAGES = [
  "ADE Extraction",
  "Normalization",
  "Negation",
  "Severity",
  "Frequency",
  "Sentiment",
];

const PIPELINE = [
  { icon: FileText, label: "Patient Review" },
  { icon: Brain, label: "Hybrid NLP" },
  { icon: Layers, label: "ADE + Context Extraction" },
  { icon: Hash, label: "TF-IDF + Hybrid Features + Sentiment" },
  { icon: Cpu, label: "SVM Model" },
  { icon: Gauge, label: "ADE Prediction" },
  { icon: Network, label: "Association Rule Mining" },
  { icon: Sparkles, label: "Drug–ADE Insights" },
];

function Index() {
  const [drug, setDrug] = useState("");
  const [review, setReview] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [rules, setRules] = useState<AssociationRule[]>([]);
  const [showNlp, setShowNlp] = useState(false);
  const [error, setError] = useState("");

  const reviewRef = useRef<HTMLTextAreaElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadAssociationRules().then(setRules);
  }, []);

  useEffect(() => {
    if (result && resultsRef.current) {
      resultsRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [result]);

  const onAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!drug.trim() || !review.trim()) {
      setError("Enter a drug name and a patient review to run the analysis.");
      return;
    }
    setError("");
    setLoading(true);
    setResult(null);
    try {
      setResult(await analyzeReview({ drug, review }));
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setResult(null);
    setDrug("");
    setReview("");
    setError("");
    reviewRef.current?.focus();
    reviewRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  const drugRules = result ? result.related_rules : [];
  const topRules = [...rules].sort((a, b) => b.lift - a.lift).slice(0, 5);
  const maxLift = Math.max(1, ...topRules.map((r) => r.lift));

  return (
    <div className="min-h-screen bg-background text-foreground antialiased">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-border bg-card/75 backdrop-blur-xl">
        <div className="mx-auto grid max-w-[1160px] grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-4 sm:flex sm:justify-between">
          <div className="flex min-w-0 items-center gap-3">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-gradient text-primary-foreground shadow-lift">
              <Activity className="h-5 w-5" aria-hidden />
            </div>
            <div className="min-w-0">
              <p className="truncate text-[15px] font-semibold tracking-tight">
                Drug–ADE Insight Engine
              </p>
              <p className="truncate text-xs text-muted-foreground">
                Hybrid NLP-powered Drug–Adverse Event Analysis
              </p>
            </div>
          </div>
          <Pill tone="teal">
            <span className="h-1.5 w-1.5 rounded-full bg-teal" aria-hidden />
            Research Prototype
          </Pill>
        </div>
      </header>

      <main className="mx-auto max-w-[1160px] px-5 pb-20">
        {/* Hero */}
        <section className="relative py-12 sm:py-16">
          <div
            className="hero-glow pointer-events-none absolute inset-x-[-20%] top-[-6rem] -z-10 h-[26rem]"
            aria-hidden
          />
          <span className="inline-flex items-center gap-2 rounded-full border border-accent/25 bg-info-soft px-3 py-1 text-xs font-medium text-accent">
            <Sparkles className="h-3.5 w-3.5" aria-hidden />
            Hybrid NLP · SVM · Association Rule Mining
          </span>
          <h1 className="mt-5 max-w-3xl text-3xl font-semibold leading-tight tracking-tight sm:text-[2.75rem]">
            Analyze patient-generated medication reviews for{" "}
            <span className="text-gradient">possible adverse drug events</span>
          </h1>
          <p className="mt-4 max-w-2xl text-[15px] leading-relaxed text-muted-foreground">
            Identify possible adverse drug events, predict whether a review is
            ADE-related, and explore Drug–ADE patterns discovered from review data.
          </p>
        </section>

        {/* Input */}
        <section aria-labelledby="input-heading">
          <Card className="p-6 sm:p-8">
            <h2 id="input-heading" className="text-lg font-semibold tracking-tight">
              Analyze a Patient Review
            </h2>
            <form className="mt-6 space-y-5" onSubmit={onAnalyze}>
              <div className="max-w-md">
                <label htmlFor="drug" className="text-sm font-medium">
                  Drug Name
                </label>
                <input
                  id="drug"
                  value={drug}
                  onChange={(e) => setDrug(e.target.value)}
                  placeholder="Enter drug name"
                  className="mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-ring/40"
                />
              </div>

              <div>
                <label htmlFor="review" className="text-sm font-medium">
                  Patient Review
                </label>
                <textarea
                  id="review"
                  ref={reviewRef}
                  value={review}
                  onChange={(e) => setReview(e.target.value)}
                  rows={6}
                  placeholder="Enter a patient review about the medication..."
                  className="mt-2 w-full resize-y rounded-xl border border-input bg-background px-4 py-3 text-sm leading-relaxed outline-none transition focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-ring/40"
                />
                <button
                  type="button"
                  onClick={() => {
                    setDrug(EXAMPLE_INPUT.drug);
                    setReview(EXAMPLE_INPUT.review);
                    setError("");
                  }}
                  className="mt-3 inline-flex items-center gap-1.5 rounded-lg border border-border bg-secondary px-3 py-1.5 text-xs font-medium text-secondary-foreground transition hover:bg-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                >
                  <Sparkles className="h-3.5 w-3.5" aria-hidden />
                  Try Example
                </button>
              </div>

              {error ? (
                <p role="alert" className="text-sm font-medium text-destructive">
                  {error}
                </p>
              ) : null}

              <button
                type="submit"
                disabled={loading}
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-brand-gradient px-6 py-3 text-sm font-semibold text-primary-foreground shadow-card transition hover:-translate-y-0.5 hover:shadow-lift hover:brightness-110 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring disabled:opacity-70 sm:w-auto"
              >
                {loading ? (
                  <>
                    <span
                      className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-primary-foreground/40 border-t-primary-foreground"
                      aria-hidden
                    />
                    Analyzing review...
                  </>
                ) : (
                  <>
                    Analyze Review
                    <ArrowRight className="h-4 w-4" aria-hidden />
                  </>
                )}
              </button>
            </form>
          </Card>
        </section>

        <div ref={resultsRef} className="scroll-mt-6" />

        {result ? (
          <div className="reveal space-y-8 pt-10">
            {/* Review Analysis */}
            <section aria-labelledby="analysis-heading">
              <SectionTitle
                icon={<FileText className="h-5 w-5" aria-hidden />}
                title="Review Analysis"
                badge={
                  <Pill tone="teal">
                    <CheckCircle2 className="h-3.5 w-3.5" aria-hidden />
                    Analysis completed
                  </Pill>
                }
              />
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <div className="rounded-xl border border-border bg-card p-4 shadow-card sm:col-span-2">
                  <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    <AlertTriangle className="h-4 w-4 text-accent" aria-hidden />
                    Detected ADEs
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {result.detected_ades.length ? (
                      result.detected_ades.map((a) => (
                        <Pill key={a} tone="info">
                          {a}
                        </Pill>
                      ))
                    ) : (
                      <span className="text-sm text-muted-foreground">
                        No possible ADE mentions detected in this review.
                      </span>
                    )}
                  </div>
                </div>
                <Stat icon={<Hash className="h-4 w-4" aria-hidden />} label="ADE Count">
                  {result.ade_count}
                </Stat>
                <Stat
                  icon={<Gauge className="h-4 w-4" aria-hidden />}
                  label="Severity"
                >
                  {result.severity}
                </Stat>
                <Stat icon={<Timer className="h-4 w-4" aria-hidden />} label="Frequency">
                  {result.frequency}
                </Stat>
                <Stat
                  icon={<Activity className="h-4 w-4" aria-hidden />}
                  label="Sentiment"
                >
                  {result.sentiment}
                </Stat>
                <div className="rounded-xl border border-border bg-background p-4 sm:col-span-2">
                  <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    <BarChart3 className="h-4 w-4 text-accent" aria-hidden />
                    Confidence
                  </div>
                  <div className="mt-2 flex items-center gap-3">
                    <span className="text-base font-semibold">
                      {pct(result.sentiment_confidence)}
                    </span>
                    <Meter
                      value={result.sentiment_confidence}
                      label="Sentiment analysis confidence"
                    />
                  </div>
                </div>
              </div>

              {/* NLP detail */}
              <div className="mt-4 rounded-xl border border-border bg-surface">
                <button
                  type="button"
                  aria-expanded={showNlp}
                  onClick={() => setShowNlp((s) => !s)}
                  className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left text-sm font-medium focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                >
                  <span className="flex items-center gap-2 text-muted-foreground">
                    <Brain className="h-4 w-4" aria-hidden />
                    Hybrid NLP Analysis
                  </span>
                  <ChevronDown
                    className={`h-4 w-4 text-muted-foreground transition-transform ${showNlp ? "rotate-180" : ""}`}
                    aria-hidden
                  />
                </button>
                {showNlp ? (
                  <div className="border-t border-border px-4 py-4">
                    <ol className="flex flex-col gap-2 text-xs text-muted-foreground sm:flex-row sm:flex-wrap sm:items-center">
                      {NLP_STAGES.map((s, i) => (
                        <li key={s} className="flex items-center gap-2">
                          <span className="rounded-md border border-border bg-card px-2.5 py-1 font-medium text-secondary-foreground">
                            {s}
                          </span>
                          {i < NLP_STAGES.length - 1 ? (
                            <ArrowRight className="h-3.5 w-3.5 shrink-0" aria-hidden />
                          ) : null}
                        </li>
                      ))}
                    </ol>
                    <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
                      Stages of the hybrid NLP methodology used to extract ADEs and
                      their context from a review.
                    </p>
                  </div>
                ) : null}
              </div>
            </section>

            {/* Prediction */}
            <section aria-labelledby="prediction-heading">
              <Card className="p-6 sm:p-8">
                <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 sm:flex sm:justify-between">
                  <h2
                    id="prediction-heading"
                    className="flex min-w-0 items-center gap-2.5 text-lg font-semibold tracking-tight sm:text-xl"
                  >
                    <Cpu className="h-5 w-5 shrink-0 text-accent" aria-hidden />
                    <span className="truncate">ADE Prediction</span>
                  </h2>
                  <Pill tone="info">SVM</Pill>
                </div>

                <p className="mt-4 text-xs uppercase tracking-wide text-muted-foreground">
                  Feature Set
                </p>
                <p className="mt-1 text-sm font-medium">
                  TF-IDF + Hybrid NLP Features + Sentiment
                </p>

                <div className="mt-6 grid gap-6 rounded-2xl border border-border bg-surface p-5 sm:grid-cols-[auto_minmax(0,1fr)] sm:items-center">
                  <div>
                    <p className="text-xs uppercase tracking-wide text-muted-foreground">
                      Prediction
                    </p>
                    <p className="mt-1 flex items-center gap-2 text-2xl font-semibold tracking-tight">
                      {result.prediction === "ADE-related" ? (
                        <AlertTriangle className="h-5 w-5 text-warn" aria-hidden />
                      ) : (
                        <CheckCircle2 className="h-5 w-5 text-teal" aria-hidden />
                      )}
                      {result.prediction}
                    </p>
                  </div>
                  <div>
                    <div className="flex items-baseline justify-between">
                      <span className="text-xs uppercase tracking-wide text-muted-foreground">
                        Confidence
                      </span>
                      <span className="text-3xl font-semibold tracking-tight">
                        {pct(result.prediction_confidence)}
                      </span>
                    </div>
                    <div className="mt-2">
                      <Meter
                        value={result.prediction_confidence}
                        label="Model prediction confidence"
                        size="lg"
                      />
                    </div>
                  </div>
                </div>

                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  {result.prediction === "ADE-related"
                    ? "The model predicts that this review is likely to contain an adverse drug event."
                    : "The model predicts that this review is unlikely to contain an adverse drug event."}
                </p>

                {!result.is_live_model ? (
                  <p className="mt-3 inline-flex items-center gap-2 rounded-lg border border-warn/30 bg-warn-soft px-3 py-2 text-xs font-medium text-warn">
                    <AlertTriangle className="h-3.5 w-3.5" aria-hidden />
                    An SVM model is used for this prediction — it is not connected yet
                  </p>
                ) : null}
              </Card>
            </section>

            {/* Relationship insights */}
            <section aria-labelledby="arm-heading">
              <Card className="p-6 sm:p-8">
                <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 sm:flex sm:justify-between">
                  <h2
                    id="arm-heading"
                    className="flex min-w-0 items-center gap-2.5 text-lg font-semibold tracking-tight sm:text-xl"
                  >
                    <Network className="h-5 w-5 shrink-0 text-accent" aria-hidden />
                    <span className="truncate">Drug–ADE Relationship Insights</span>
                  </h2>
                  <Pill tone="teal">Association Rule Mining</Pill>
                </div>
                <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">
                  Association rule mining can identify recurring relationships between
                  medications and adverse drug events across the available review
                  dataset. These are patterns observed in data, not causal findings.
                </p>

                <div className="mt-6 space-y-3">
                  {drugRules.length ? (
                    drugRules.map((r) => (
                      <div
                        key={`${r.drug}-${r.ade}`}
                        className="rounded-xl border border-border bg-background p-4 transition hover:shadow-card"
                      >
                        <p className="flex flex-wrap items-center gap-2 text-sm font-semibold">
                          {r.drug}
                          <ArrowRight
                            className="h-4 w-4 text-muted-foreground"
                            aria-hidden
                          />
                          {r.ade}
                        </p>
                        <dl className="mt-3 flex flex-wrap gap-x-8 gap-y-2 text-xs text-muted-foreground">
                          <div>
                            <dt className="uppercase tracking-wide">Support</dt>
                            <dd className="mt-0.5 text-sm font-medium text-foreground">
                              {(r.support * 100).toFixed(1)}%
                            </dd>
                          </div>
                          <div>
                            <dt className="uppercase tracking-wide">Confidence</dt>
                            <dd className="mt-0.5 text-sm font-medium text-foreground">
                              {(r.confidence * 100).toFixed(1)}%
                            </dd>
                          </div>
                          <div>
                            <dt className="uppercase tracking-wide">Lift</dt>
                            <dd className="mt-0.5 text-sm font-medium text-foreground">
                              {r.lift.toFixed(2)}×
                            </dd>
                          </div>
                        </dl>
                      </div>
                    ))
                  ) : (
                    <p className="rounded-xl border border-dashed border-border bg-surface p-4 text-sm text-muted-foreground">
                      No strong Drug–ADE relationship identified in the available data.
                    </p>
                  )}
                </div>

                {/* Visualization */}
                <div className="mt-8 border-t border-border pt-6">
                  <h3 className="text-sm font-semibold tracking-tight">
                    Strongest Drug–ADE Associations
                  </h3>
                  <ul className="mt-4 space-y-3">
                    {topRules.map((r) => (
                      <li key={`viz-${r.drug}-${r.ade}`}>
                        <div className="flex items-baseline justify-between gap-3 text-xs">
                          <span className="min-w-0 truncate font-medium text-foreground">
                            {r.drug} → {r.ade}
                          </span>
                          <span className="shrink-0 text-muted-foreground">
                            Lift {r.lift.toFixed(2)}×
                          </span>
                        </div>
                        <div
                          className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-muted"
                          role="img"
                          aria-label={`${r.drug} to ${r.ade}, lift ${r.lift.toFixed(2)} times`}
                        >
                          <div
                            className="meter-fill h-full rounded-full bg-teal"
                            style={{ width: `${(r.lift / maxLift) * 100}%` }}
                          />
                        </div>
                      </li>
                    ))}
                  </ul>
                  <p className="mt-4 text-xs text-muted-foreground">
                    Rules are supplied dynamically and update when new mining results
                    (Apriori, FP-Growth) are provided.
                  </p>
                </div>
              </Card>
            </section>

            {/* Summary */}
            <section aria-labelledby="summary-heading">
              <Card className="p-6 sm:p-8">
                <h2 id="summary-heading" className="text-lg font-semibold tracking-tight">
                  Analysis Summary
                </h2>
                <dl className="mt-5 grid gap-x-10 gap-y-4 sm:grid-cols-2">
                  {[
                    ["Drug", result.drug],
                    [
                      "Detected ADEs",
                      result.detected_ades.length
                        ? result.detected_ades.join(", ")
                        : "None detected",
                    ],
                    ["Sentiment", result.sentiment],
                    ["ADE Prediction", result.prediction],
                    ["Confidence", pct(result.prediction_confidence)],
                    [
                      "Related Drug–ADE Patterns",
                      `${drugRules.length} identified`,
                    ],
                  ].map(([k, v]) => (
                    <div
                      key={k}
                      className="flex items-baseline justify-between gap-4 border-b border-border pb-3"
                    >
                      <dt className="text-sm text-muted-foreground">{k}</dt>
                      <dd className="text-right text-sm font-medium">{v}</dd>
                    </div>
                  ))}
                </dl>

                <button
                  type="button"
                  onClick={reset}
                  className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-input bg-secondary px-6 py-3 text-sm font-semibold text-secondary-foreground transition hover:bg-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring sm:w-auto"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden />
                  Analyze Another Review
                </button>
              </Card>
            </section>
          </div>
        ) : null}

        {/* Pipeline */}
        <section aria-labelledby="pipeline-heading" className="pt-14">
          <SectionTitle title="How the Engine Works" />
          <div className="rounded-2xl border border-border bg-surface p-6">
            <ol className="flex flex-col gap-3 lg:flex-row lg:flex-wrap lg:items-stretch">
              {PIPELINE.map((step, i) => (
                <li key={step.label} className="flex items-center gap-3 lg:flex-1">
                  <div className="flex min-w-0 flex-1 items-center gap-2.5 rounded-xl border border-border bg-card px-3 py-2.5">
                    <step.icon className="h-4 w-4 shrink-0 text-accent" aria-hidden />
                    <span className="min-w-0 text-xs font-medium leading-snug">
                      {step.label}
                    </span>
                  </div>
                  {i < PIPELINE.length - 1 ? (
                    <ArrowRight
                      className="h-4 w-4 shrink-0 rotate-90 text-muted-foreground lg:rotate-0"
                      aria-hidden
                    />
                  ) : null}
                </li>
              ))}
            </ol>
            <p className="mt-5 text-xs text-muted-foreground">
              An end-to-end pharmacovigilance analysis workflow, from patient review to
              interpretable Drug–ADE insights.
            </p>
          </div>
        </section>
      </main>

      <footer className="border-t border-border bg-card">
        <div className="mx-auto max-w-[1160px] space-y-2 px-5 py-8">
          <p className="max-w-3xl text-xs leading-relaxed text-muted-foreground">
            Research prototype based on patient-generated review data. Predictions and
            associations indicate patterns in the data and do not establish medical
            causality or provide medical advice.
          </p>
          <p className="text-xs font-medium text-secondary-foreground">
            Drug–ADE Insight Engine · Research Prototype
          </p>
        </div>
      </footer>
    </div>
  );
}
