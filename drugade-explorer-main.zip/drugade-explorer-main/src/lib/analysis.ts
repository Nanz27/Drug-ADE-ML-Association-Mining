/**
 * Analysis layer for the Drug-ADE Insight Engine.
 *
 * Everything here is DEMO logic. It is intentionally isolated behind
 * `analyzeReview()` and `loadAssociationRules()` so that both can later be
 * replaced by real API calls (e.g. `POST /analyze`) without touching the UI.
 */

export type AnalysisRequest = {
  drug: string;
  review: string;
};

export type AssociationRule = {
  drug: string;
  ade: string;
  support: number; // 0..1
  confidence: number; // 0..1
  lift: number;
};

export type AnalysisResult = {
  drug: string;
  detected_ades: string[];
  ade_count: number;
  severity: "Mild" | "Moderate" | "Severe" | "Not specified";
  frequency: "Rare" | "Occasional" | "Frequent" | "Not specified";
  sentiment: "Positive" | "Neutral" | "Negative";
  sentiment_confidence: number; // 0..1
  prediction: "ADE-related" | "Not ADE-related";
  prediction_confidence: number; // 0..1
  related_rules: AssociationRule[];
  /** false until the SVM model / NLP pipeline is connected */
  is_live_model: boolean;
};

export const EXAMPLE_INPUT: AnalysisRequest = {
  drug: "Sertraline",
  review:
    "I started taking sertraline a few weeks ago. It has helped with my mood, but I occasionally feel nauseous and dizzy, especially after taking my morning dose.",
};

/**
 * Demo association-rule set. Replace with a fetch from the mining backend
 * (Apriori / FP-Growth output). The UI never assumes a fixed drug or ADE list.
 */
const DEMO_RULES: AssociationRule[] = [
  { drug: "Sertraline", ade: "Anxiety", support: 0.163, confidence: 0.595, lift: 3.66 },
  { drug: "Sertraline", ade: "Nausea", support: 0.141, confidence: 0.512, lift: 2.94 },
  { drug: "Sertraline", ade: "Dizziness", support: 0.098, confidence: 0.401, lift: 2.31 },
  { drug: "Fluoxetine", ade: "Headache", support: 0.127, confidence: 0.486, lift: 2.72 },
  { drug: "Fluoxetine", ade: "Insomnia", support: 0.104, confidence: 0.437, lift: 2.18 },
  { drug: "Metformin", ade: "Diarrhea", support: 0.211, confidence: 0.632, lift: 3.12 },
  { drug: "Atorvastatin", ade: "Muscle pain", support: 0.156, confidence: 0.548, lift: 2.87 },
];

export async function loadAssociationRules(): Promise<AssociationRule[]> {
  // Future: return (await fetch('/api/rules')).json()
  return DEMO_RULES;
}

export function rulesForDrug(rules: AssociationRule[], drug: string): AssociationRule[] {
  const key = drug.trim().toLowerCase();
  if (!key) return [];
  return rules
    .filter((r) => r.drug.toLowerCase() === key)
    .sort((a, b) => b.lift - a.lift);
}

/* ---------------- demo NLP heuristics ---------------- */

const ADE_LEXICON: Record<string, string> = {
  nausea: "Nausea",
  nauseous: "Nausea",
  nauseated: "Nausea",
  sick: "Nausea",
  vomit: "Vomiting",
  vomiting: "Vomiting",
  dizzy: "Dizziness",
  dizziness: "Dizziness",
  lightheaded: "Dizziness",
  headache: "Headache",
  migraine: "Headache",
  insomnia: "Insomnia",
  sleepless: "Insomnia",
  "cannot sleep": "Insomnia",
  drowsy: "Drowsiness",
  drowsiness: "Drowsiness",
  fatigue: "Fatigue",
  tired: "Fatigue",
  anxiety: "Anxiety",
  anxious: "Anxiety",
  rash: "Rash",
  itching: "Itching",
  diarrhea: "Diarrhea",
  constipation: "Constipation",
  "dry mouth": "Dry mouth",
  "weight gain": "Weight gain",
  "muscle pain": "Muscle pain",
  cramps: "Muscle pain",
  palpitations: "Palpitations",
  tremor: "Tremor",
  sweating: "Sweating",
};

const NEGATIONS = ["no ", "not ", "never ", "without ", "didn't ", "did not ", "no more "];

const SEVERITY_TERMS: Array<[RegExp, AnalysisResult["severity"]]> = [
  [/\b(severe|unbearable|extreme|intense|debilitating|terrible)\b/i, "Severe"],
  [/\b(moderate|noticeable|bothersome|uncomfortable)\b/i, "Moderate"],
  [/\b(mild|slight|minor|manageable|a little)\b/i, "Mild"],
];

const FREQUENCY_TERMS: Array<[RegExp, AnalysisResult["frequency"]]> = [
  [/\b(constantly|always|every day|daily|frequently|often)\b/i, "Frequent"],
  [/\b(occasionally|sometimes|now and then|at times|once in a while)\b/i, "Occasional"],
  [/\b(rarely|seldom|once|hardly ever)\b/i, "Rare"],
];

const NEGATIVE_TERMS = /\b(bad|worse|awful|terrible|horrible|stopped|quit|regret|struggle|uncomfortable|unbearable)\b/i;
const POSITIVE_TERMS = /\b(helped|helping|better|improved|great|good|effective|relief|works|working)\b/i;

function isNegated(text: string, index: number) {
  const window = text.slice(Math.max(0, index - 28), index).toLowerCase();
  return NEGATIONS.some((n) => window.includes(n));
}

function extractAdes(review: string): string[] {
  const lower = review.toLowerCase();
  const found = new Set<string>();
  for (const [term, normalized] of Object.entries(ADE_LEXICON)) {
    const idx = lower.indexOf(term);
    if (idx >= 0 && !isNegated(lower, idx)) found.add(normalized);
  }
  return [...found];
}

function detect<T>(text: string, table: Array<[RegExp, T]>, fallback: T): T {
  for (const [re, value] of table) if (re.test(text)) return value;
  return fallback;
}

function clamp(n: number, min = 0, max = 1) {
  return Math.min(max, Math.max(min, n));
}

/**
 * Demo inference. Replace body with:
 *   const res = await fetch('/analyze', { method: 'POST', body: JSON.stringify(req) })
 *   return res.json()
 */
export async function analyzeReview(req: AnalysisRequest): Promise<AnalysisResult> {
  await new Promise((r) => setTimeout(r, 1200));

  const review = req.review.trim();
  const detected = extractAdes(review);
  const severity = detect(review, SEVERITY_TERMS, detected.length ? "Moderate" : "Not specified");
  const frequency = detect(review, FREQUENCY_TERMS, detected.length ? "Occasional" : "Not specified");

  const negHits = (review.match(NEGATIVE_TERMS) ? 1 : 0) + detected.length;
  const posHits = review.match(POSITIVE_TERMS) ? 1 : 0;
  const sentiment: AnalysisResult["sentiment"] =
    negHits > posHits ? "Negative" : posHits > negHits ? "Positive" : "Neutral";

  const sentiment_confidence = clamp(0.62 + Math.abs(negHits - posHits) * 0.14 + detected.length * 0.05, 0, 0.97);

  const isAde = detected.length > 0;
  const prediction_confidence = clamp(
    isAde ? 0.68 + detected.length * 0.07 + (severity === "Severe" ? 0.08 : 0.04) : 0.71,
    0,
    0.96,
  );

  const rules = await loadAssociationRules();

  return {
    drug: req.drug.trim(),
    detected_ades: detected,
    ade_count: detected.length,
    severity,
    frequency,
    sentiment,
    sentiment_confidence: Number(sentiment_confidence.toFixed(2)),
    prediction: isAde ? "ADE-related" : "Not ADE-related",
    prediction_confidence: Number(prediction_confidence.toFixed(2)),
    related_rules: rulesForDrug(rules, req.drug),
    is_live_model: false,
  };
}
